import { Bricolage_Grotesque } from "next/font/google";
import "./globals.css";

const display = Bricolage_Grotesque({
  subsets: ["latin"],
  variable: "--font-display",
});

export const metadata = {
  title: "Tenggat",
  description: "Lihat semua deadline di satu garis waktu, lengkap dengan pengingat.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="id" className={display.variable}>
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
