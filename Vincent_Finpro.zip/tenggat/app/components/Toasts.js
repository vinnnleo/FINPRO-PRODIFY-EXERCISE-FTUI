"use client";

// Notifikasi di dalam halaman (tetap muncul walau notifikasi browser diblokir).
export default function Toasts({ toasts, onClose }) {
  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      className="fixed bottom-4 right-4 z-50 flex w-[calc(100%-2rem)] max-w-sm flex-col gap-2"
    >
      {toasts.map((t) => (
        <div
          key={t.key}
          className={`toast-in flex items-start gap-3 rounded-lg px-4 py-3 shadow-lg ${
            t.type === "due" ? "bg-cherry text-paper" : "bg-navy text-paper"
          }`}
        >
          <div className="min-w-0 flex-1">
            <p className="text-[15px] font-semibold leading-snug">{t.title}</p>
            {t.body && <p className="mt-0.5 text-sm opacity-80">{t.body}</p>}
          </div>
          <button
            type="button"
            onClick={() => onClose(t.key)}
            className="text-sm opacity-70 hover:opacity-100"
          >
            Tutup
          </button>
        </div>
      ))}
    </div>
  );
}
