"use client";

import { countdown, formatDue } from "@/lib/time";

const PRIORITY = {
  high: { ring: "border-cherry", fill: "bg-cherry", label: "Prioritas tinggi" },
  medium: { ring: "border-amber", fill: "bg-amber", label: "Prioritas sedang" },
  low: { ring: "border-teal", fill: "bg-teal", label: "Prioritas rendah" },
};

export default function TaskRow({ task, now, onToggle, onEdit, onDelete }) {
  const p = PRIORITY[task.priority] ?? PRIORITY.medium;
  const late = !task.completed && new Date(task.dueAt) < now;

  return (
    <li className="group grid grid-cols-[auto_1fr_auto] items-center gap-x-3 gap-y-1 border-b border-line px-1 py-3 last:border-b-0 sm:grid-cols-[auto_1fr_7rem_10rem_9rem_auto]">
      {/* tombol selesai: lingkaran berwarna sesuai prioritas */}
      <button
        type="button"
        onClick={() => onToggle(task)}
        aria-label={task.completed ? "Tandai belum selesai" : "Tandai selesai"}
        title={p.label}
        className={`flex h-5 w-5 items-center justify-center rounded-full border-2 ${p.ring} ${
          task.completed ? p.fill : "hover:bg-fog"
        }`}
      >
        {task.completed && (
          <svg viewBox="0 0 12 12" className="h-3 w-3 text-paper" aria-hidden>
            <path d="M2.5 6.5l2.2 2.2L9.5 3.8" fill="none" stroke="currentColor" strokeWidth="2" />
          </svg>
        )}
      </button>

      <button
        type="button"
        onClick={() => onEdit(task)}
        className="min-w-0 text-left"
      >
        <span
          className={`block truncate text-[15px] font-semibold ${
            task.completed ? "text-slate line-through decoration-1" : ""
          }`}
        >
          {task.title}
        </span>
        {task.notes && <span className="block truncate text-sm text-slate">{task.notes}</span>}
      </button>

      <span className="hidden text-sm text-slate sm:block">{task.category}</span>
      <span className="tnum col-start-2 text-sm text-slate sm:col-start-auto">
        {formatDue(task.dueAt)}
      </span>
      <span
        className={`tnum col-start-2 text-sm font-semibold sm:col-start-auto sm:text-right ${
          late ? "text-cherry" : "text-navy"
        } ${task.completed ? "invisible" : ""}`}
      >
        {countdown(task.dueAt, now)}
      </span>

      <button
        type="button"
        onClick={() => onDelete(task)}
        aria-label={`Hapus ${task.title}`}
        className="col-start-3 row-start-1 rounded p-1 text-slate hover:text-cherry sm:col-start-auto sm:row-start-auto sm:opacity-0 sm:group-hover:opacity-100 sm:focus:opacity-100"
      >
        <svg viewBox="0 0 16 16" className="h-4 w-4" aria-hidden>
          <path
            d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.6 8.5h5.8l.6-8.5"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.4"
          />
        </svg>
      </button>
    </li>
  );
}
