"use client";

import { useState } from "react";
import { REMINDER_OPTIONS } from "@/lib/time";
import { CATEGORIES } from "@/lib/constants";

export const EMPTY_FORM = {
  title: "",
  notes: "",
  dueAt: "",
  remindBefore: 60,
  priority: "medium",
  category: "Kuliah",
};

const field =
  "w-full rounded-md border border-line bg-paper px-3 py-2 text-[15px] outline-none transition-colors focus:border-navy";
const label = "flex flex-col gap-1 text-sm text-slate";

const PRIORITY_OPTIONS = [
  ["low", "Rendah", "bg-teal"],
  ["medium", "Sedang", "bg-amber"],
  ["high", "Tinggi", "bg-cherry"],
];

// Mode "quick": satu baris (judul + deadline), opsi lain bisa dibuka.
// Mode "full": semua field langsung tampil (dipakai di panel edit).
export default function TaskForm({
  initial = EMPTY_FORM,
  mode = "full",
  submitLabel,
  onSubmit,
  onCancel,
}) {
  const [form, setForm] = useState(initial);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [expanded, setExpanded] = useState(mode === "full");

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (!form.title.trim()) return setError("Tulis dulu nama tugasnya.");
    if (!form.dueAt) return setError("Pilih tanggal dan jam deadline.");

    setSaving(true);
    try {
      await onSubmit({
        ...form,
        title: form.title.trim(),
        notes: form.notes.trim(),
        remindBefore: Number(form.remindBefore),
        dueAt: new Date(form.dueAt).toISOString(),
      });
      if (mode === "quick") {
        setForm(EMPTY_FORM);
        setExpanded(false);
      }
    } catch (err) {
      setError(err?.response?.data?.error || "Server tidak merespons. Coba simpan lagi.");
    } finally {
      setSaving(false);
    }
  }

  const titleInput = (
    <input
      className={field}
      placeholder="Nama tugas, mis. Laporan Praktikum Modul 4"
      value={form.title}
      onChange={set("title")}
      maxLength={120}
      aria-label="Nama tugas"
    />
  );
  const dueInput = (
    <input
      type="datetime-local"
      className={field}
      value={form.dueAt}
      onChange={set("dueAt")}
      aria-label="Deadline"
    />
  );

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      {mode === "quick" ? (
        <div className="grid gap-2 sm:grid-cols-[1fr_14rem_auto]">
          {titleInput}
          {dueInput}
          <button
            type="submit"
            disabled={saving}
            className="rounded-md bg-navy px-5 py-2 text-[15px] font-semibold text-paper transition-opacity hover:opacity-90 disabled:opacity-50"
          >
            {saving ? "Menyimpan…" : submitLabel}
          </button>
        </div>
      ) : (
        <>
          <label className={label}>
            Nama tugas
            {titleInput}
          </label>
          <label className={label}>
            Deadline
            {dueInput}
          </label>
        </>
      )}

      {mode === "quick" && (
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          aria-expanded={expanded}
          className="self-start text-sm text-slate underline decoration-line underline-offset-4 hover:text-navy"
        >
          {expanded ? "Sembunyikan detail" : "Tambah catatan, kategori, prioritas, pengingat"}
        </button>
      )}

      {expanded && (
        <div className="grid gap-3 sm:grid-cols-2">
          <label className={`${label} sm:col-span-2`}>
            Catatan
            <textarea
              className={`${field} resize-none`}
              rows={2}
              value={form.notes}
              onChange={set("notes")}
              maxLength={500}
            />
          </label>
          <label className={label}>
            Kategori
            <select className={field} value={form.category} onChange={set("category")}>
              {CATEGORIES.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
          <label className={label}>
            Ingatkan aku
            <select className={field} value={form.remindBefore} onChange={set("remindBefore")}>
              {REMINDER_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </label>
          <fieldset className={`${label} sm:col-span-2`}>
            <legend className="mb-1">Prioritas</legend>
            <div className="flex gap-2">
              {PRIORITY_OPTIONS.map(([value, text, dot]) => (
                <button
                  key={value}
                  type="button"
                  aria-pressed={form.priority === value}
                  onClick={() => setForm((f) => ({ ...f, priority: value }))}
                  className={`flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm transition-colors ${
                    form.priority === value
                      ? "border-navy bg-navy text-paper"
                      : "border-line bg-paper text-navy hover:border-navy"
                  }`}
                >
                  <span className={`h-2 w-2 rounded-full ${dot}`} />
                  {text}
                </button>
              ))}
            </div>
          </fieldset>
        </div>
      )}

      {error && (
        <p role="alert" className="text-sm font-medium text-cherry">
          {error}
        </p>
      )}

      {mode === "full" && (
        <div className="mt-1 flex gap-2">
          <button
            type="submit"
            disabled={saving}
            className="rounded-md bg-navy px-5 py-2 text-[15px] font-semibold text-paper hover:opacity-90 disabled:opacity-50"
          >
            {saving ? "Menyimpan…" : submitLabel}
          </button>
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="rounded-md px-4 py-2 text-[15px] text-slate hover:text-navy"
            >
              Batal
            </button>
          )}
        </div>
      )}
    </form>
  );
}
