"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import axios from "axios";
import Timeline from "./Timeline";
import TaskForm from "./TaskForm";
import TaskRow from "./TaskRow";
import Toasts from "./Toasts";
import {
  LANES,
  laneOf,
  countdown,
  formatDue,
  formatToday,
  reminderLabel,
  toLocalInput,
} from "@/lib/time";
import { CATEGORIES } from "@/lib/constants";

const POLL_MS = 10 * 1000; // cek pengingat tiap 10 detik

export default function Board() {
  const [tasks, setTasks] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [now, setNow] = useState(null); // null sampai halaman tampil di browser
  const [toasts, setToasts] = useState([]);
  const [permission, setPermission] = useState("default");

  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Semua");
  const [showDone, setShowDone] = useState(false);
  const [editing, setEditing] = useState(null);

  const handled = useRef(new Set()); // pengingat yang sudah diproses di sesi ini

  // ---------- helper ----------
  function pushToast(toast) {
    const key = toast.key ?? `${Date.now()}-${Math.random()}`;
    setToasts((prev) => (prev.some((t) => t.key === key) ? prev : [...prev, { ...toast, key }]));
    if (toast.type === "info") {
      setTimeout(() => setToasts((prev) => prev.filter((t) => t.key !== key)), 2500);
    }
  }

  function replaceTask(updated) {
    setTasks((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
  }

  // ---------- load awal + jam berjalan ----------
  useEffect(() => {
    setNow(new Date());
    setPermission("Notification" in window ? Notification.permission : "unsupported");

    axios
      .get("/api/tasks")
      .then((res) => setTasks(res.data))
      .catch(() =>
        pushToast({ type: "due", title: "Tugas gagal dimuat", body: "Pastikan server berjalan, lalu muat ulang halaman." })
      )
      .finally(() => setLoaded(true));

    const tick = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(tick);
  }, []);

  // ---------- polling pengingat ----------
  useEffect(() => {
    async function checkReminders() {
      try {
        const { data } = await axios.get("/api/reminders");
        for (const { type, task } of data) {
          const key = `${task.id}-${type}-${task.dueAt}`;
          if (handled.current.has(key)) continue;
          handled.current.add(key);

          const title = type === "early" ? `Sebentar lagi: ${task.title}` : `Deadline sekarang: ${task.title}`;
          const body =
            type === "early"
              ? `Deadline ${formatDue(task.dueAt)}. Kamu minta diingatkan ${reminderLabel(task.remindBefore)}.`
              : task.notes || "Waktunya dikumpulkan.";

          pushToast({ key, type, title, body });

          if ("Notification" in window && Notification.permission === "granted") {
            const n = new Notification(title, { body, tag: key, requireInteraction: true });
            n.onclick = () => {
              window.focus();
              n.close();
            };
          }

          const res = await axios.post("/api/reminders/ack", { id: task.id, type });
          replaceTask(res.data);
        }
      } catch (err) {
        console.error("Gagal cek pengingat:", err);
      }
    }

    checkReminders();
    const id = setInterval(checkReminders, POLL_MS);
    return () => clearInterval(id);
  }, []);

  // Tutup panel edit dengan Escape
  useEffect(() => {
    if (!editing) return;
    const onKey = (e) => e.key === "Escape" && setEditing(null);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [editing]);

  // ---------- aksi ----------
  async function enableNotifications() {
    if (!("Notification" in window)) return;
    const result = await Notification.requestPermission();
    setPermission(result);
    if (result === "granted") {
      new Notification("Notifikasi Tenggat nyala", { body: "Kamu akan diingatkan sebelum deadline." });
    }
  }

  async function addTask(payload) {
    const res = await axios.post("/api/tasks", payload);
    setTasks((prev) => [...prev, res.data]);
    pushToast({ type: "info", title: `Ditambahkan: ${res.data.title}` });
  }

  async function saveEdit(payload) {
    const res = await axios.patch(`/api/tasks/${editing.id}`, payload);
    replaceTask(res.data);
    setEditing(null);
    pushToast({ type: "info", title: "Perubahan disimpan" });
  }

  async function toggleTask(task) {
    try {
      const res = await axios.patch(`/api/tasks/${task.id}`, { completed: !task.completed });
      replaceTask(res.data);
    } catch {
      pushToast({ type: "due", title: "Status tugas gagal diubah", body: "Coba lagi sebentar." });
    }
  }

  async function deleteTask(task) {
    if (!window.confirm(`Hapus "${task.title}"? Tugas yang dihapus tidak bisa dikembalikan.`)) return;
    try {
      await axios.delete(`/api/tasks/${task.id}`);
      setTasks((prev) => prev.filter((t) => t.id !== task.id));
      if (editing?.id === task.id) setEditing(null);
    } catch {
      pushToast({ type: "due", title: "Tugas gagal dihapus", body: "Coba lagi sebentar." });
    }
  }

  // ---------- data turunan ----------
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const rank = { high: 0, medium: 1, low: 2 };
    return tasks
      .filter((t) => category === "Semua" || t.category === category)
      .filter((t) => !q || t.title.toLowerCase().includes(q) || (t.notes || "").toLowerCase().includes(q))
      .sort((a, b) => new Date(a.dueAt) - new Date(b.dueAt) || rank[a.priority] - rank[b.priority]);
  }, [tasks, query, category]);

  const groups = useMemo(() => {
    const g = { overdue: [], today: [], week: [], later: [], done: [] };
    if (now) filtered.forEach((t) => g[laneOf(t, now)].push(t));
    g.done.sort((a, b) => new Date(b.completedAt) - new Date(a.completedAt));
    return g;
  }, [filtered, now]);

  const summary = useMemo(() => {
    if (!now) return null;
    const active = tasks.filter((t) => !t.completed);
    const overdue = active.filter((t) => new Date(t.dueAt) < now);
    const next = active
      .filter((t) => new Date(t.dueAt) >= now)
      .sort((a, b) => new Date(a.dueAt) - new Date(b.dueAt))[0];
    return { active: active.length, overdue: overdue.length, next, total: tasks.length };
  }, [tasks, now]);

  useEffect(() => {
    if (!summary) return;
    document.title = summary.overdue > 0 ? `(${summary.overdue}) Tenggat` : "Tenggat";
  }, [summary?.overdue]);

  const rowProps = { now, onToggle: toggleTask, onEdit: setEditing, onDelete: deleteTask };

  // ---------- tampilan ----------
  return (
    <div className="mx-auto max-w-6xl px-4 pb-24 pt-8 sm:px-8">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-5xl font-extrabold tracking-[-0.03em] sm:text-6xl">Tenggat</h1>
          {now && <p className="mt-1 text-slate">{formatToday(now)}</p>}
        </div>
        <NotificationControl permission={permission} onEnable={enableNotifications} />
      </header>

      {summary && (
        <p className="mt-6 max-w-[60ch] text-xl leading-relaxed sm:text-2xl">
          {summary.total === 0 ? (
            "Belum ada tugas. Tulis deadline pertamamu di bawah."
          ) : summary.active === 0 ? (
            "Semua tugas sudah selesai."
          ) : (
            <>
              {summary.active} tugas aktif
              {summary.overdue > 0 && (
                <span className="text-cherry">, {summary.overdue} sudah lewat deadline</span>
              )}
              .{" "}
              {summary.next && (
                <>
                  Berikutnya{" "}
                  <button
                    type="button"
                    onClick={() => setEditing(summary.next)}
                    className="font-semibold underline decoration-line decoration-2 underline-offset-4 hover:decoration-navy"
                  >
                    {summary.next.title}
                  </button>
                  , <span className="tnum">{countdown(summary.next.dueAt, now)}</span>.
                </>
              )}
            </>
          )}
        </p>
      )}

      {/* garis waktu */}
      <section aria-label="Garis waktu deadline" className="mt-8 rounded-xl bg-paper px-4 pb-3 pt-3 sm:px-6">
        {now && loaded ? (
          <Timeline tasks={tasks} now={now} onSelect={setEditing} />
        ) : (
          <div className="h-32" />
        )}
      </section>

      {/* tambah tugas */}
      <section className="mt-6">
        <h2 className="mb-2 text-lg font-bold">Tambah tugas</h2>
        <TaskForm mode="quick" submitLabel="Tambah" onSubmit={addTask} />
      </section>

      {/* daftar */}
      <section className="mt-10">
        <div className="flex flex-col gap-3 border-b-2 border-navy pb-3 sm:flex-row sm:items-center sm:justify-between">
          <nav aria-label="Filter kategori" className="flex flex-wrap gap-x-4 gap-y-1">
            {["Semua", ...CATEGORIES].map((c) => (
              <button
                key={c}
                type="button"
                aria-pressed={category === c}
                onClick={() => setCategory(c)}
                className={`text-[15px] ${
                  category === c ? "font-bold text-navy" : "text-slate hover:text-navy"
                }`}
              >
                {c}
              </button>
            ))}
          </nav>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cari tugas"
            aria-label="Cari tugas"
            className="w-full rounded-md border border-line bg-paper px-3 py-1.5 text-[15px] outline-none focus:border-navy sm:w-56"
          />
        </div>

        {!loaded || !now ? (
          <p className="py-10 text-slate">Memuat tugas…</p>
        ) : (
          <>
            {LANES.map((lane) =>
              groups[lane.id].length === 0 ? null : (
                <div key={lane.id} className="mt-6">
                  <h3
                    className={`flex items-baseline gap-2 text-sm font-bold ${
                      lane.id === "overdue" ? "text-cherry" : "text-slate"
                    }`}
                  >
                    {lane.title}
                    <span className="tnum font-normal">{groups[lane.id].length}</span>
                  </h3>
                  <ul className="mt-1">
                    {groups[lane.id].map((t) => (
                      <TaskRow key={t.id} task={t} {...rowProps} />
                    ))}
                  </ul>
                </div>
              )
            )}

            {filtered.filter((t) => !t.completed).length === 0 && (
              <p className="mt-6 text-slate">
                {query || category !== "Semua"
                  ? "Tidak ada tugas aktif yang cocok dengan filter ini."
                  : "Tidak ada tugas aktif."}
              </p>
            )}

            {groups.done.length > 0 && (
              <div className="mt-8">
                <button
                  type="button"
                  aria-expanded={showDone}
                  onClick={() => setShowDone((v) => !v)}
                  className="text-sm font-bold text-slate hover:text-navy"
                >
                  {showDone ? "Sembunyikan" : "Tampilkan"} {groups.done.length} tugas selesai
                </button>
                {showDone && (
                  <ul className="mt-1">
                    {groups.done.map((t) => (
                      <TaskRow key={t.id} task={t} {...rowProps} />
                    ))}
                  </ul>
                )}
              </div>
            )}
          </>
        )}
      </section>

      {/* panel edit dari samping */}
      {editing && (
        <div
          className="fixed inset-0 z-40 bg-navy/30"
          onClick={(e) => e.target === e.currentTarget && setEditing(null)}
        >
          <aside
            role="dialog"
            aria-label="Edit tugas"
            className="toast-in absolute inset-y-0 right-0 w-full max-w-md overflow-y-auto bg-paper p-6 shadow-xl"
          >
            <div className="mb-5 flex items-start justify-between gap-4">
              <h2 className="text-2xl font-bold leading-tight">Edit tugas</h2>
              <button
                type="button"
                onClick={() => setEditing(null)}
                className="text-sm text-slate hover:text-navy"
              >
                Tutup
              </button>
            </div>
            <TaskForm
              key={editing.id}
              initial={{
                title: editing.title,
                notes: editing.notes || "",
                dueAt: toLocalInput(editing.dueAt),
                remindBefore: editing.remindBefore,
                priority: editing.priority,
                category: editing.category,
              }}
              submitLabel="Simpan perubahan"
              onSubmit={saveEdit}
              onCancel={() => setEditing(null)}
            />
            <button
              type="button"
              onClick={() => deleteTask(editing)}
              className="mt-8 text-sm text-cherry hover:underline"
            >
              Hapus tugas ini
            </button>
          </aside>
        </div>
      )}

      <Toasts toasts={toasts} onClose={(key) => setToasts((prev) => prev.filter((t) => t.key !== key))} />
    </div>
  );
}

function NotificationControl({ permission, onEnable }) {
  if (permission === "granted") {
    return (
      <p className="flex items-center gap-2 text-sm text-slate">
        <span className="h-2 w-2 rounded-full bg-teal" />
        Notifikasi browser nyala
      </p>
    );
  }
  if (permission === "unsupported") {
    return <p className="text-sm text-slate">Browser ini tidak mendukung notifikasi</p>;
  }
  if (permission === "denied") {
    return (
      <p className="max-w-xs text-sm text-slate">
        Notifikasi diblokir. Izinkan lewat ikon gembok di address bar.
      </p>
    );
  }
  return (
    <button
      type="button"
      onClick={onEnable}
      className="self-start rounded-md border-2 border-navy px-4 py-1.5 text-sm font-semibold hover:bg-navy hover:text-paper sm:self-auto"
    >
      Nyalakan notifikasi
    </button>
  );
}
