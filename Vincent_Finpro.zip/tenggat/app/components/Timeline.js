"use client";

import { DAY, countdown, formatClock } from "@/lib/time";

// Garis waktu: 12 jam ke belakang sampai 7 hari ke depan.
// Setiap tugas aktif diletakkan tepat di posisi jam deadline-nya.
const PAST = DAY / 2;
const FUTURE = 7 * DAY;
const ROW_H = 44;
const MIN_GAP = 17; // jarak minimum antar label dalam satu baris (persen)
const MAX_ROWS = 4;

const PRIORITY_DOT = {
  high: "bg-cherry",
  medium: "bg-amber",
  low: "bg-teal",
};

export default function Timeline({ tasks, now, onSelect }) {
  const start = now.getTime() - PAST;
  const end = now.getTime() + FUTURE;
  const pos = (t) => ((t - start) / (end - start)) * 100;
  const nowX = pos(now.getTime());

  const active = tasks
    .filter((t) => !t.completed)
    .map((t) => ({ task: t, time: new Date(t.dueAt).getTime() }))
    .sort((a, b) => a.time - b.time);

  const tooOld = active.filter((a) => a.time < start);
  const beyond = active.filter((a) => a.time > end);
  const visible = active.filter((a) => a.time >= start && a.time <= end);

  // Susun label ke beberapa baris supaya tidak saling tumpuk
  const rowEnds = [];
  const placed = visible.map((a) => {
    const x = pos(a.time);
    let row = rowEnds.findIndex((last) => x - last >= MIN_GAP);
    if (row === -1) {
      row = rowEnds.length < MAX_ROWS ? rowEnds.length : rowEnds.indexOf(Math.min(...rowEnds));
    }
    rowEnds[row] = x;
    return { ...a, x, row };
  });

  const rows = Math.max(1, rowEnds.length);
  const height = rows * ROW_H + 24;

  // Garis pemisah hari (setiap tengah malam)
  const days = [];
  const d = new Date(start);
  d.setHours(24, 0, 0, 0);
  while (d.getTime() < end) {
    days.push(new Date(d));
    d.setDate(d.getDate() + 1);
  }

  return (
    <div className="overflow-x-auto pb-2 pt-6">
      <div className="relative min-w-[880px]">
        {/* area label */}
        <div className="relative" style={{ height }}>
          {/* zona yang sudah lewat */}
          <div
            className="absolute inset-y-0 left-0 bg-cherry/[0.06]"
            style={{ width: `${nowX}%` }}
          />

          {days.map((day) => (
            <div
              key={day.toISOString()}
              className="absolute inset-y-0 w-px bg-line"
              style={{ left: `${pos(day.getTime())}%` }}
            />
          ))}

          {/* garis sekarang */}
          <div className="absolute inset-y-0 w-0.5 bg-cherry" style={{ left: `${nowX}%` }}>
            <span className="tnum absolute -top-5 left-1/2 -translate-x-1/2 whitespace-nowrap text-[11px] font-bold text-cherry">
              {formatClock(now)}
            </span>
          </div>

          {placed.map(({ task, x, row }) => {
            const late = new Date(task.dueAt) < now;
            const flip = x > 82; // label di kanan diletakkan ke kiri garis
            return (
              <button
                key={task.id}
                type="button"
                onClick={() => onSelect(task)}
                className="group absolute z-10 flex items-start"
                style={{
                  left: `${x}%`,
                  bottom: 0,
                  height: height - row * ROW_H - 8,
                  transform: flip ? "translateX(-100%)" : undefined,
                  flexDirection: flip ? "row-reverse" : "row",
                }}
              >
                <span className={`w-px self-stretch ${late ? "bg-cherry" : "bg-navy/50"}`} />
                <span
                  className={`-mt-px max-w-[160px] rounded-md border bg-paper px-2 py-1 text-left shadow-[0_1px_0_var(--color-line)] transition-colors group-hover:border-navy ${
                    flip ? "text-right" : ""
                  } ${late ? "border-cherry/60" : "border-line"}`}
                >
                  <span className="flex items-center gap-1.5 text-[13px] font-semibold leading-tight">
                    <span className={`h-2 w-2 shrink-0 rounded-full ${PRIORITY_DOT[task.priority]}`} />
                    <span className="truncate">{task.title}</span>
                  </span>
                  <span className={`tnum block text-[11px] ${late ? "text-cherry" : "text-slate"}`}>
                    {countdown(task.dueAt, now)}
                  </span>
                </span>
              </button>
            );
          })}

        </div>

        {/* sumbu hari */}
        <div className="relative h-7 border-t-2 border-navy">
          {days.map((day) => (
            <span
              key={day.toISOString()}
              className="absolute top-1.5 pl-1.5 text-xs text-slate"
              style={{ left: `${pos(day.getTime())}%` }}
            >
              <span className="font-semibold text-navy">
                {day.toLocaleDateString("id-ID", { weekday: "short" })}
              </span>{" "}
              {day.getDate()}
            </span>
          ))}
        </div>

        {(tooOld.length > 0 || beyond.length > 0) && (
          <div className="flex justify-between text-xs text-slate">
            <span>{tooOld.length > 0 && `${tooOld.length} tugas lewat lebih dari 12 jam`}</span>
            <span>
              {beyond.length > 0 && `${beyond.length} tugas lagi setelah 7 hari ke depan`}
            </span>
          </div>
        )}

        {active.length === 0 && (
          <p className="absolute inset-x-0 top-6 text-center text-sm text-slate">
            Belum ada deadline. Tambahkan tugas pertamamu di bawah.
          </p>
        )}
      </div>
    </div>
  );
}

