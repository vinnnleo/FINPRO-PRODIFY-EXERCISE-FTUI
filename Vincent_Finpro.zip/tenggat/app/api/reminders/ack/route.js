import { NextResponse } from "next/server";
import { readTasks, writeTasks } from "@/lib/store";

// POST /api/reminders/ack  { id, type: "early" | "due" }
// Menandai pengingat sudah dikirim supaya tidak muncul berulang.
export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body harus JSON." }, { status: 400 });
  }

  const { id, type } = body;
  if (!["early", "due"].includes(type)) {
    return NextResponse.json({ error: "Tipe tidak valid." }, { status: 400 });
  }

  const tasks = readTasks();
  const task = tasks.find((t) => t.id === id);
  if (!task) {
    return NextResponse.json({ error: "Tugas tidak ditemukan." }, { status: 404 });
  }

  task.earlySent = true; // deadline lewat = pengingat awal juga tidak perlu lagi
  if (type === "due") task.dueSent = true;
  writeTasks(tasks);

  return NextResponse.json(task);
}
