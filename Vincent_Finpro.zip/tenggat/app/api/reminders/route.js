import { NextResponse } from "next/server";
import { readTasks, pendingReminders } from "@/lib/store";

// GET /api/reminders — daftar pengingat yang harus ditampilkan sekarang
export async function GET(request) {
  const reminders = pendingReminders(readTasks(), new Date());
  return NextResponse.json(reminders);
}
