import { NextResponse } from "next/server";
import { readTasks, writeTasks, validateTask, createTask } from "@/lib/store";

// GET /api/tasks?status=active|done&q=kata
export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");
  const q = (searchParams.get("q") || "").toLowerCase();

  let tasks = readTasks();
  if (status === "active") tasks = tasks.filter((t) => !t.completed);
  if (status === "done") tasks = tasks.filter((t) => t.completed);
  if (q) {
    tasks = tasks.filter(
      (t) =>
        t.title.toLowerCase().includes(q) || t.notes.toLowerCase().includes(q)
    );
  }

  tasks.sort((a, b) => new Date(a.dueAt) - new Date(b.dueAt));
  return NextResponse.json(tasks);
}

// POST /api/tasks
export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body harus JSON." }, { status: 400 });
  }

  const { errors, clean } = validateTask(body);
  if (errors.length) {
    return NextResponse.json({ error: errors.join(" ") }, { status: 400 });
  }

  const tasks = readTasks();
  const task = createTask(clean);
  tasks.push(task);
  writeTasks(tasks);

  return NextResponse.json(task, { status: 201 });
}
