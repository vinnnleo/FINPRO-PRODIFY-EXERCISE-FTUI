import { NextResponse } from "next/server";
import { readTasks, writeTasks, validateTask } from "@/lib/store";

function notFound() {
  return NextResponse.json({ error: "Tugas tidak ditemukan." }, { status: 404 });
}

// GET /api/tasks/:id
export async function GET(request, { params }) {
  const { id } = await params;
  const task = readTasks().find((t) => t.id === id);
  return task ? NextResponse.json(task) : notFound();
}

// PATCH /api/tasks/:id  — hanya field yang dikirim yang diubah
export async function PATCH(request, { params }) {
  const { id } = await params;
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body harus JSON." }, { status: 400 });
  }

  const tasks = readTasks();
  const index = tasks.findIndex((t) => t.id === id);
  if (index === -1) return notFound();

  const { errors, clean } = validateTask(body, true);
  if (errors.length) {
    return NextResponse.json({ error: errors.join(" ") }, { status: 400 });
  }

  const old = tasks[index];
  const updated = { ...old, ...clean, updatedAt: new Date().toISOString() };

  // Kalau deadline / waktu pengingat diubah, pengingat dijadwalkan ulang.
  if (
    (clean.dueAt && clean.dueAt !== old.dueAt) ||
    (clean.remindBefore !== undefined && clean.remindBefore !== old.remindBefore)
  ) {
    updated.earlySent = false;
    updated.dueSent = false;
  }

  if (clean.completed !== undefined) {
    updated.completedAt = clean.completed ? new Date().toISOString() : null;
  }

  tasks[index] = updated;
  writeTasks(tasks);
  return NextResponse.json(updated);
}

// DELETE /api/tasks/:id
export async function DELETE(request, { params }) {
  const { id } = await params;
  const tasks = readTasks();
  const remaining = tasks.filter((t) => t.id !== id);
  if (remaining.length === tasks.length) return notFound();

  writeTasks(remaining);
  return NextResponse.json({ success: true });
}
